Cannon
======

Cannon, hitting targets with projectiles.

.. literalinclude:: ../freegames/cannon.py
