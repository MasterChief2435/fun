.. include:: ../README.rst

.. toctree::
   :hidden:

   give-gift-python
   curriculum
   api
   development
   guess
   snake
   crypto
   paint
   maze
   flappy
   bagels
   tictactoe
   ant
   simonsays
   cannon
   bounce
   pong
   life
   tron
   tiles
   connect
   memory
   pacman
   fidget
