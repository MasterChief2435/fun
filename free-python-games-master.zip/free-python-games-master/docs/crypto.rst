Crypto
======

Crypto: tool for encrypting and decrypting messages.

.. literalinclude:: ../freegames/crypto.py
